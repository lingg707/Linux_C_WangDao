#include <stdio.h>
#define NUM 1+2
int main()
{
	int i=NUM*NUM;
	int j=10;
	printf("i=%d\n",i);
	return 0;
}

